import React, { useState } from 'react';
import { Link, useLocation, Outlet, useNavigate } from 'react-router-dom';
import { Menu, X, Search, Bell, PlayCircle, LogIn, LogOut, ArrowRight, ChevronDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';

const Layout: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { user, openAuthModal, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path: string) => location.pathname === path;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalog?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-dark text-slate-200 font-sans selection:bg-primary/30">
      <AuthModal />
      
      {/* Header */}
      <header className="fixed top-0 w-full z-50 glass border-b border-white/5 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20 gap-4">
            
            {/* Left Section: Logo */}
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="flex items-center gap-2 group">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/20 group-hover:scale-105 transition-transform">
                  <PlayCircle className="w-6 h-6 fill-current" />
                </div>
                <span className="font-display text-2xl font-black tracking-tight text-white group-hover:text-glow transition-all hidden sm:block">
                  Anime<span className="text-primary">Stream</span>
                </span>
                <span className="font-display text-2xl font-black tracking-tight text-white group-hover:text-glow transition-all sm:hidden">
                  A<span className="text-primary">S</span>
                </span>
              </Link>
            </div>

            {/* Center Section: Search Bar */}
            <div className="flex-1 hidden md:flex justify-center px-6">
              <form onSubmit={handleSearch} className="relative w-full max-w-lg group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-slate-500 group-focus-within:text-primary transition-colors" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Найти аниме..."
                  className="block w-full h-10 pl-11 pr-12 bg-surface/50 border border-white/10 rounded-xl leading-normal text-slate-300 placeholder-slate-500 focus:outline-none focus:bg-surface focus:border-primary/50 focus:ring-4 focus:ring-primary/10 sm:text-sm transition-all duration-300"
                />
                <button 
                  type="submit" 
                  className="absolute inset-y-1 right-1 px-3 flex items-center bg-white/5 hover:bg-primary text-slate-400 hover:text-white rounded-lg transition-colors"
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
              </form>
            </div>

            {/* Right Section: Nav & Actions */}
            <div className="flex items-center gap-4 lg:gap-6 flex-shrink-0">
              <div className="hidden lg:flex items-center gap-6 text-sm font-bold uppercase tracking-wider">
                <Link to="/" className={`${isActive('/') ? 'text-accent' : 'text-slate-400 hover:text-white'} transition-colors`}>Главная</Link>
                
                {/* Dropdown for Catalog */}
                <div className="relative group h-20 flex items-center cursor-pointer">
                  <span className={`flex items-center gap-1 ${isActive('/catalog') ? 'text-accent' : 'text-slate-400 group-hover:text-white'} transition-colors py-2`}>
                    Каталог <ChevronDown className="w-3 h-3 group-hover:rotate-180 transition-transform" />
                  </span>
                  <div className="absolute top-[80%] right-1/2 translate-x-1/2 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 w-48 z-50">
                    <div className="glass rounded-xl border border-white/10 overflow-hidden shadow-2xl p-1 bg-[#0f172a]">
                      <Link to="/catalog" className="block px-4 py-2.5 text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors">Все аниме</Link>
                      <Link to="/catalog?sort=trending" className="block px-4 py-2.5 text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors">В тренде</Link>
                      <Link to="/catalog?sort=new" className="block px-4 py-2.5 text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors">Новинки</Link>
                      <Link to="/catalog?category=upcoming" className="block px-4 py-2.5 text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors">Анонсы</Link>
                    </div>
                  </div>
                </div>

                <Link to="/news" className={`${isActive('/news') ? 'text-accent' : 'text-slate-400 hover:text-white'} transition-colors`}>Новости</Link>
              </div>

              <div className="hidden lg:block w-px h-8 bg-white/10"></div>

              {/* User Actions */}
              <div className="hidden md:flex items-center gap-4">
                {user ? (
                  <>
                    <button className="w-10 h-10 flex items-center justify-center text-slate-400 hover:bg-white/5 hover:text-white rounded-xl transition-colors relative">
                      <Bell className="w-5 h-5" />
                      <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-accent rounded-full border-2 border-dark"></span>
                    </button>
                    <div className="relative group">
                      <Link to="/profile" className="block w-10 h-10 rounded-xl overflow-hidden ring-2 ring-white/5 hover:ring-accent/50 transition-all cursor-pointer">
                        <img src={user.avatar} alt="User" className="w-full h-full object-cover" />
                      </Link>
                      <div className="absolute right-0 top-full pt-2 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                        <div className="glass rounded-xl border border-white/10 p-1 bg-[#0f172a] shadow-xl">
                           <div className="px-4 py-3 border-b border-white/5 mb-1">
                             <p className="text-sm font-bold text-white truncate">{user.name}</p>
                             <p className="text-xs text-slate-500 truncate">Premium Member</p>
                           </div>
                           <Link to="/profile" className="block px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-white/5 rounded-lg">Профиль</Link>
                           <Link to="/profile" className="block px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-white/5 rounded-lg">Настройки</Link>
                           <div className="h-px bg-white/5 my-1"></div>
                           <button 
                             onClick={logout}
                             className="w-full flex items-center gap-2 px-4 py-2 text-sm font-bold text-red-400 hover:bg-white/5 hover:text-red-300 rounded-lg transition-colors text-left"
                           >
                             <LogOut className="w-4 h-4" /> Выйти
                           </button>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <button 
                    onClick={openAuthModal}
                    className="h-10 px-5 bg-primary hover:bg-violet-600 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-primary/20 hover:shadow-primary/40 flex items-center gap-2"
                  >
                    <LogIn className="w-4 h-4" /> <span>Войти</span>
                  </button>
                )}
              </div>

              {/* Mobile Menu Button */}
              <button
                className="md:hidden p-2 text-slate-400 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden glass border-b border-white/5 animate-in slide-in-from-top-5">
            <div className="px-4 pt-2 pb-6 space-y-4">
              <form onSubmit={(e) => { handleSearch(e); setIsMenuOpen(false); }} className="relative w-full mb-4">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Поиск..."
                  className="w-full pl-12 pr-12 py-3 bg-surface border border-white/10 rounded-xl text-sm outline-none text-white"
                />
                <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-white/5 hover:bg-primary text-white rounded-lg">
                   <ArrowRight className="w-4 h-4" />
                </button>
              </form>
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-white hover:bg-white/5">Главная</Link>
              <Link to="/catalog" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-300 hover:text-white hover:bg-white/5">Каталог</Link>
              <div className="pl-6 space-y-2 border-l border-white/10">
                 <Link to="/catalog?sort=trending" onClick={() => setIsMenuOpen(false)} className="block px-3 py-1 text-sm text-slate-400 hover:text-white">В тренде</Link>
                 <Link to="/catalog?sort=new" onClick={() => setIsMenuOpen(false)} className="block px-3 py-1 text-sm text-slate-400 hover:text-white">Новинки</Link>
                 <Link to="/catalog?category=upcoming" onClick={() => setIsMenuOpen(false)} className="block px-3 py-1 text-sm text-slate-400 hover:text-white">Анонсы</Link>
              </div>
              <Link to="/news" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-300 hover:text-white hover:bg-white/5">Новости</Link>
              {user && (
                <Link to="/profile" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-300 hover:text-white hover:bg-white/5">Профиль</Link>
              )}
              {user ? (
                 <button onClick={() => { logout(); setIsMenuOpen(false); }} className="w-full text-left block px-3 py-2 rounded-md text-base font-medium text-red-400 hover:bg-white/5">Выйти</button>
              ) : (
                 <button onClick={() => { openAuthModal(); setIsMenuOpen(false); }} className="w-full text-left block px-3 py-2 rounded-md text-base font-medium text-primary hover:bg-white/5">Войти / Регистрация</button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow pt-24 pb-12">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-surface border-t border-white/5 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center text-white shadow-lg shadow-primary/20">
                   <PlayCircle className="w-5 h-5 fill-current" />
                </div>
                <span className="font-display text-xl font-black tracking-tight text-white">
                  Anime<span className="text-primary">Stream</span>
                </span>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                Лучшее место для просмотра аниме в высоком качестве. Присоединяйтесь к нашему сообществу и смотрите новинки без рекламы.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold text-white mb-6 uppercase text-xs tracking-wider">Навигация</h4>
              <ul className="space-y-3 text-sm text-slate-400">
                <li><Link to="/" className="hover:text-primary transition-colors">Главная</Link></li>
                <li><Link to="/catalog" className="hover:text-primary transition-colors">Каталог</Link></li>
                <li><Link to="/news" className="hover:text-primary transition-colors">Новости</Link></li>
                <li>
                  {user ? (
                    <Link to="/profile" className="hover:text-primary transition-colors">Профиль</Link>
                  ) : (
                    <button onClick={openAuthModal} className="hover:text-primary transition-colors text-left">Профиль</button>
                  )}
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6 uppercase text-xs tracking-wider">Помощь</h4>
              <ul className="space-y-3 text-sm text-slate-400">
                <li><Link to="/faq" className="hover:text-primary transition-colors">FAQ</Link></li>
                <li><Link to="/contact" className="hover:text-primary transition-colors">Контакты</Link></li>
                <li><Link to="/dmca" className="hover:text-primary transition-colors">DMCA</Link></li>
                <li><Link to="/terms" className="hover:text-primary transition-colors">Правила сервиса</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6 uppercase text-xs tracking-wider">Соцсети</h4>
              <div className="flex gap-4">
                <button className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all text-slate-400">
                  <span className="font-bold">vk</span>
                </button>
                <button className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all text-slate-400">
                   <span className="font-bold">tg</span>
                </button>
                <button className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all text-slate-400">
                   <span className="font-bold">ds</span>
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500 uppercase tracking-wide">
            <p>&copy; 2024 AnimeStream. Все права защищены.</p>
            <div className="flex gap-6">
              <Link to="/privacy" className="hover:text-white">Конфиденциальность</Link>
              <Link to="/terms" className="hover:text-white">Cookies</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;