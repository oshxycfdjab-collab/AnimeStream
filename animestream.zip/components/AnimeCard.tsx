import React from 'react';
import { Link } from 'react-router-dom';
import { Star, PlayCircle } from 'lucide-react';
import { Anime } from '../types';

interface AnimeCardProps {
  anime: Anime;
  rank?: number;
}

const AnimeCard: React.FC<AnimeCardProps> = ({ anime, rank }) => {
  const episodeCount = `${anime.episodesAired || 0} / ${anime.episodes || '?'}`;

  return (
    <Link to={`/anime/${anime.id}`} className="group block relative w-full">
      {/* Image Container */}
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-3 bg-surface border border-white/5 group-hover:border-primary/50 transition-all shadow-lg group-hover:shadow-primary/20">
        <img 
          src={anime.image} 
          alt={anime.title} 
          className="w-full h-full object-cover transition duration-700 group-hover:scale-110 will-change-transform" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-transparent to-transparent opacity-60" />
        
        {/* Rating Badge */}
        <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-black/60 backdrop-blur-md rounded-md flex items-center gap-1">
          <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
          <span className="text-xs font-bold text-white">{anime.rating}</span>
        </div>

        {/* Rank Badge */}
        {rank && (
          <div className="absolute top-2 left-2 px-2 py-0.5 bg-primary/90 backdrop-blur-md text-[10px] font-black uppercase rounded shadow-lg text-white">
            #{rank}
          </div>
        )}

        {/* Hover Overlay with Play Button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/20">
          <div className="w-12 h-12 bg-primary/90 rounded-full flex items-center justify-center text-white scale-75 group-hover:scale-100 transition-transform shadow-glow backdrop-blur-sm">
            <PlayCircle className="w-6 h-6 fill-current" />
          </div>
        </div>
      </div>
      
      {/* Text Content - Static height to prevent layout shifts */}
      <div className="px-1">
        <h3 className="font-bold text-base text-slate-200 group-hover:text-primary transition-colors line-clamp-1" title={anime.title}>
          {anime.title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>{anime.year}</span>
          <span className="w-1 h-1 rounded-full bg-slate-600" />
          <span>{episodeCount} эп.</span>
          <span className="w-1 h-1 rounded-full bg-slate-600" />
          <span className="truncate">{anime.type}</span>
        </div>
      </div>
    </Link>
  );
};

export default AnimeCard;