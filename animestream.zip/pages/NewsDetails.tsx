import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, ArrowLeft, Loader2 } from 'lucide-react';
import { fetchNewsDetails } from '../services/shikimori';
import { NewsItem } from '../types';

const NewsDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [newsItem, setNewsItem] = useState<NewsItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (!id) return;
      setIsLoading(true);
      const data = await fetchNewsDetails(id);
      setNewsItem(data);
      setIsLoading(false);
    };
    loadData();
  }, [id]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (!newsItem) {
    return (
        <div className="flex flex-col items-center justify-center min-h-[50vh] text-slate-400">
            <h2 className="text-xl font-bold mb-4">Новость не найдена</h2>
            <Link to="/news" className="text-primary hover:text-white transition-colors">Вернуться к списку</Link>
        </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/news" className="inline-flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-white transition-colors mb-8">
        <ArrowLeft className="w-4 h-4" /> Все новости
      </Link>

      <article className="glass rounded-2xl border border-white/5 p-8 md:p-12 relative overflow-hidden">
        {/* Background Gradient */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-[100px] pointer-events-none"></div>

        <header className="mb-10 relative z-10 border-b border-white/5 pb-8">
             <div className="flex items-center gap-3 text-sm mb-6">
                 <span className="px-3 py-1 bg-primary/10 text-primary border border-primary/20 rounded-lg font-bold uppercase tracking-wide text-xs">
                     {newsItem.category}
                 </span>
                 <span className="flex items-center gap-2 text-slate-500 font-bold uppercase text-xs">
                     <Calendar className="w-3 h-3" /> {newsItem.date}
                 </span>
             </div>
             <h1 className="text-3xl md:text-5xl font-display font-black text-white leading-tight">
                 {newsItem.title}
             </h1>
        </header>

        <div className="relative z-10">
           <div 
             className="prose prose-invert prose-lg max-w-none text-slate-300 news-content"
             dangerouslySetInnerHTML={{ __html: newsItem.html_body || newsItem.summary }} 
           />
        </div>
      </article>
    </div>
  );
};

export default NewsDetails;