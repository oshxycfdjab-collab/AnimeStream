
import React, { useEffect, useState } from 'react';
import { History, Heart, Settings, Clock, PlayCircle, LogIn, Loader2, Mail } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db } from '../services/db';
import { fetchAnimes } from '../services/shikimori';
import { Anime } from '../types';
import { Link } from 'react-router-dom';

const Profile: React.FC = () => {
  const { user, openAuthModal } = useAuth();
  const [favorites, setFavorites] = useState<Anime[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!user?.email) return;

    const loadUserData = async () => {
      setIsLoading(true);
      try {
        // Load Favorites from Cloud
        const favIds = await db.getFavorites(user.email);
        if (favIds.length > 0) {
          const favData = await Promise.all(
            favIds.map(async (id) => {
              const res = await fetchAnimes({ ids: id, limit: 1 });
              return res[0];
            })
          );
          setFavorites(favData.filter(a => !!a));
        } else {
          setFavorites([]);
        }

        // Load History from Cloud
        const historyData = await db.getHistory(user.email);
        setHistory(historyData);
      } catch (err) {
        console.error("Profile Load Error", err);
      } finally {
        setIsLoading(false);
      }
    };

    loadUserData();
  }, [user]);

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-8">
           <LogIn className="w-10 h-10 text-slate-600" />
        </div>
        <h2 className="text-3xl font-black text-white mb-4 uppercase tracking-tighter">Личный кабинет</h2>
        <p className="text-slate-500 mb-10 font-medium">Авторизуйтесь, чтобы синхронизировать историю просмотров и избранное между всеми вашими устройствами.</p>
        <button onClick={openAuthModal} className="px-10 py-4 bg-primary rounded-2xl font-black text-white hover:bg-violet-600 transition-all shadow-xl shadow-primary/20 uppercase tracking-widest text-xs active:scale-95">Войти в аккаунт</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex flex-col lg:flex-row gap-10">
        <aside className="w-full lg:w-80 flex-shrink-0 space-y-6">
           <div className="glass p-10 rounded-[2.5rem] flex flex-col items-center text-center relative overflow-hidden border border-white/10 shadow-2xl">
              <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-primary/30 to-transparent"></div>
              <div className="relative mb-6">
                 <div className="w-28 h-28 rounded-full border-4 border-dark overflow-hidden shadow-2xl ring-2 ring-primary/50">
                    <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
                 </div>
                 <div className="absolute bottom-1 right-1 w-6 h-6 bg-green-500 border-4 border-dark rounded-full"></div>
              </div>
              <h2 className="text-2xl font-black text-white uppercase tracking-tighter">{user.name}</h2>
              <div className="flex flex-col items-center gap-3 mt-4">
                 <span className="px-4 py-1.5 bg-primary/20 text-primary text-[10px] font-black uppercase rounded-xl border border-primary/20 tracking-[0.2em]">Пользователь</span>
                 <div className="flex items-center gap-2 text-slate-500 text-[10px] font-bold uppercase tracking-widest">
                    <Mail className="w-3 h-3" /> {user.email}
                 </div>
              </div>
           </div>

           <nav className="glass rounded-3xl overflow-hidden p-3 space-y-2 border border-white/5 shadow-xl">
              <button className="w-full flex items-center justify-between px-5 py-4 rounded-2xl bg-primary/10 text-primary border border-primary/20 group transition-all">
                <div className="flex items-center gap-3">
                   <Heart className="w-5 h-5 fill-current" />
                   <span className="font-black text-[10px] uppercase tracking-widest">Избранное</span>
                </div>
                <span className="text-[10px] font-black bg-primary text-white px-2 py-0.5 rounded-lg">{favorites.length}</span>
              </button>
              <button className="w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-slate-500 hover:bg-white/5 hover:text-white transition-all group">
                <History className="w-5 h-5 group-hover:text-primary transition-colors" />
                <span className="font-black text-[10px] uppercase tracking-widest">История</span>
              </button>
              <button className="w-full flex items-center gap-3 px-5 py-4 rounded-2xl text-slate-500 hover:bg-white/5 hover:text-white transition-all group">
                <Settings className="w-5 h-5 group-hover:text-primary transition-colors" />
                <span className="font-black text-[10px] uppercase tracking-widest">Настройки</span>
              </button>
           </nav>
        </aside>

        <div className="flex-grow space-y-12 pt-6 lg:pt-0">
           {isLoading ? (
             <div className="flex justify-center py-32"><Loader2 className="w-12 h-12 text-primary animate-spin" /></div>
           ) : (
             <>
                <section>
                   <div className="flex items-center justify-between mb-8">
                      <h3 className="text-2xl font-black text-white flex items-center gap-3 uppercase tracking-tighter">
                         <Heart className="text-primary w-6 h-6" /> Ваше избранное
                      </h3>
                      <Link to="/catalog" className="text-[10px] font-black text-primary uppercase tracking-widest hover:text-white transition-colors">Перейти в каталог</Link>
                   </div>
                   {favorites.length > 0 ? (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                         {favorites.map(anime => (
                            <Link to={`/anime/${anime.id}`} key={anime.id} className="group relative rounded-3xl overflow-hidden glass border border-transparent hover:border-primary/50 transition-all shadow-xl">
                               <div className="aspect-[2/3] relative">
                                  <img src={anime.image} alt={anime.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                                  <div className="absolute inset-0 bg-gradient-to-t from-dark via-transparent to-transparent opacity-90"></div>
                                  <div className="absolute bottom-0 left-0 right-0 p-4">
                                     <h4 className="text-xs font-black text-white truncate uppercase tracking-tighter mb-1">{anime.title}</h4>
                                     <div className="text-[9px] font-black text-primary uppercase tracking-[0.2em]">{anime.type}</div>
                                  </div>
                               </div>
                            </Link>
                         ))}
                      </div>
                   ) : (
                    <div className="p-16 text-center glass rounded-[2rem] border border-white/5">
                        <p className="text-slate-500 font-bold uppercase text-xs tracking-widest">Вы еще не добавили ни одного аниме в избранное</p>
                    </div>
                   )}
                </section>

                <section>
                   <h3 className="text-2xl font-black text-white flex items-center gap-3 uppercase tracking-tighter mb-8">
                      <History className="text-primary w-6 h-6" /> Последние просмотры
                   </h3>
                   <div className="grid gap-4">
                      {history.length > 0 ? history.map((item, idx) => (
                         <Link to={`/watch/${item.animeId}?ep=${item.episode}`} key={idx} className="glass p-4 rounded-3xl flex items-center gap-6 group border border-transparent hover:border-white/10 transition-all relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-[50px] pointer-events-none"></div>
                            <div className="w-40 h-24 rounded-2xl overflow-hidden relative shrink-0 shadow-xl">
                               <img src={item.image} alt="Thumb" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                               <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"><PlayCircle className="text-white w-10 h-10 fill-current" /></div>
                            </div>
                            <div className="flex-grow min-w-0">
                               <div className="flex items-center gap-2 mb-2">
                                  <span className="text-[10px] font-black text-primary bg-primary/10 px-2 py-0.5 rounded border border-primary/20 uppercase">Продолжить</span>
                                  <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
                                     <Clock className="w-3 h-3" /> {new Date(item.date).toLocaleDateString()}
                                  </div>
                               </div>
                               <h4 className="text-lg font-black text-white truncate uppercase tracking-tighter">{item.title}</h4>
                               <p className="text-xs text-slate-400 font-bold mt-1 uppercase tracking-wider">Остановились на <span className="text-white">{item.episode} серии</span></p>
                            </div>
                            <div className="mr-4 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0 hidden sm:block">
                               <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                                  <PlayCircle className="w-6 h-6" />
                               </div>
                            </div>
                         </Link>
                      )) : (
                        <div className="p-16 text-center glass rounded-[2rem] border border-white/5">
                            <p className="text-slate-500 font-bold uppercase text-xs tracking-widest">История просмотров пуста</p>
                        </div>
                      )}
                   </div>
                </section>
             </>
           )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
