import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ChevronDown, ArrowDownUp, Loader2 } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import AnimeCard from '../components/AnimeCard';
import { fetchAnimes, GENRE_MAP } from '../services/shikimori';
import { Anime } from '../types';

const Catalog: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const initialSort = searchParams.get('sort') || 'popularity';
  const initialCategory = searchParams.get('category') || 'All';
  
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>(initialCategory === 'upcoming' ? 'anons' : 'All');
  const [currentSort, setCurrentSort] = useState(initialSort);
  
  const [animeList, setAnimeList] = useState<Anime[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);
  const statusRef = useRef<HTMLDivElement>(null);
  const sortRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (statusRef.current && !statusRef.current.contains(event.target as Node)) setIsStatusOpen(false);
      if (sortRef.current && !sortRef.current.contains(event.target as Node)) setIsSortOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Fetch when filters change
  useEffect(() => {
    const loadInitial = async () => {
      setIsLoading(true);
      setPage(1);
      const params: any = { page: 1, order: currentSort, search: searchQuery || undefined };
      if (selectedGenre) params.genre = GENRE_MAP[selectedGenre];
      if (selectedStatus !== 'All') params.status = selectedStatus;

      const results = await fetchAnimes(params);
      setAnimeList(results);
      setHasMore(results.length >= 20);
      setIsLoading(false);
    };
    const timer = setTimeout(loadInitial, 300);
    return () => clearTimeout(timer);
  }, [searchQuery, selectedGenre, selectedStatus, currentSort]);

  const handleLoadMore = async () => {
    if (isLoadingMore || !hasMore) return;
    setIsLoadingMore(true);
    const nextPage = page + 1;
    const params: any = { page: nextPage, order: currentSort, search: searchQuery || undefined };
    if (selectedGenre) params.genre = GENRE_MAP[selectedGenre];
    if (selectedStatus !== 'All') params.status = selectedStatus;

    const newResults = await fetchAnimes(params);
    if (newResults.length > 0) {
        setAnimeList(prev => [...prev, ...newResults]);
        setPage(nextPage);
        setHasMore(newResults.length >= 20);
    } else {
        setHasMore(false);
    }
    setIsLoadingMore(false);
  };

  const genres = Object.keys(GENRE_MAP);
  const statusOptions = [
    { value: 'All', label: 'Все статусы' },
    { value: 'ongoing', label: 'Онгоинг' },
    { value: 'released', label: 'Завершен' },
    { value: 'anons', label: 'Анонс' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-10">
        <h1 className="text-4xl font-display font-black text-white">Каталог</h1>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-grow md:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 w-5 h-5" />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск аниме..." 
              className="w-full bg-surface border border-white/10 rounded-xl py-3 pl-12 pr-4 text-sm text-slate-200 outline-none focus:border-primary transition-all"
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-64 space-y-8">
          <div className="glass p-6 rounded-2xl sticky top-24">
            <h3 className="text-xs font-black uppercase text-slate-500 mb-4">Жанры</h3>
            <div className="flex flex-wrap gap-2 mb-8">
              {genres.map(genre => (
                <button 
                  key={genre} 
                  onClick={() => setSelectedGenre(selectedGenre === genre ? null : genre)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-bold border transition-all ${selectedGenre === genre ? 'bg-primary border-primary text-white shadow-lg' : 'bg-white/5 border-white/5 text-slate-400 hover:text-primary'}`}
                >
                  {genre}
                </button>
              ))}
            </div>
            
            <h3 className="text-xs font-black uppercase text-slate-500 mb-4">Статус</h3>
            <select 
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-slate-300 outline-none focus:border-primary"
            >
                {statusOptions.map(o => <option key={o.value} value={o.value} className="bg-dark">{o.label}</option>)}
            </select>
          </div>
        </aside>

        <div className="flex-grow">
          {isLoading ? (
             <div className="flex justify-center py-20"><Loader2 className="w-10 h-10 text-primary animate-spin" /></div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-6">
                {animeList.map((anime, idx) => <AnimeCard key={`${anime.id}-${idx}`} anime={anime} />)}
              </div>
              {hasMore && (
                <div className="mt-12 flex justify-center">
                  <button onClick={handleLoadMore} disabled={isLoadingMore} className="px-8 py-3 glass border border-white/10 rounded-xl text-sm font-bold text-slate-300 hover:text-white transition-all flex items-center gap-2">
                    {isLoadingMore && <Loader2 className="w-4 h-4 animate-spin" />}
                    {isLoadingMore ? 'Загрузка...' : 'Загрузить еще'}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Catalog;