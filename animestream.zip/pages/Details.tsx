
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Play, Heart, Share2, Clock, PlayCircle, Loader2, MessageSquare, Calendar } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { fetchAnimeDetails, fetchComments } from '../services/shikimori';
import { db } from '../services/db';
import { Anime, Episode, Comment } from '../types';

const Details: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { openAuthModal, user } = useAuth();
  
  const [anime, setAnime] = useState<Anime | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isActionLoading, setIsActionLoading] = useState(false);

  useEffect(() => {
    const loadDetails = async () => {
      if (!id) return;
      setIsLoading(true);
      const data = await fetchAnimeDetails(id);
      setAnime(data);

      if (data) {
          if (data.status !== 'Upcoming' && data.episodesAired !== 0) {
              const totalEpisodes = data.episodesAired; 
              const epList: Episode[] = Array.from({ length: totalEpisodes }, (_, i) => ({
                  id: `ep-${data.id}-${i + 1}`,
                  number: i + 1,
                  title: `Эпизод ${i + 1}`,
                  duration: "24:00",
                  thumbnail: data.cover || data.image,
                  isFiller: false
              }));
              setEpisodes(epList);
          }
          const commentsData = await fetchComments(id);
          setComments(commentsData);

          // Favorite check from Cloud
          if (user?.email) {
            const userFavs = await db.getFavorites(user.email);
            setIsFavorite(userFavs.includes(id));
          }
      }
      setIsLoading(false);
    };
    loadDetails();
  }, [id, user]);

  const handleFavorite = async () => {
    if (!user?.email) {
      openAuthModal();
      return;
    }
    setIsActionLoading(true);
    const newState = await db.toggleFavorite(user.email, id!);
    setIsFavorite(newState);
    setIsActionLoading(false);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    alert("Ссылка на аниме скопирована!");
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-12 h-12 text-primary animate-spin" /></div>;
  }

  if (!anime) return <div className="text-center py-20 text-white font-bold">Аниме не найдено или удалено</div>;

  const hasContent = episodes.length > 0;

  return (
    <div className="-mt-8">
      <div className="relative h-[65vh] w-full">
        <img src={anime.cover || anime.image} alt={anime.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-dark/80 via-transparent to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 -mt-48 pb-20">
        <div className="flex flex-col lg:flex-row gap-12">
          
          <div className="w-full lg:w-80 flex-shrink-0">
            <div className="aspect-[2/3] rounded-[2rem] overflow-hidden shadow-2xl border border-white/10 mb-8 ring-1 ring-white/10 group">
              <img src={anime.image} alt={anime.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
            </div>
            
            <div className="space-y-4">
              {hasContent ? (
                  <Link to={`/watch/${anime.id}`} className="w-full py-5 bg-primary hover:bg-violet-600 text-white font-black rounded-2xl flex items-center justify-center gap-3 transition-all shadow-xl shadow-primary/30 transform hover:-translate-y-1 active:scale-95 text-sm uppercase tracking-widest">
                    <Play className="w-6 h-6 fill-current" /> Смотреть серию
                  </Link>
              ) : (
                  <button disabled className="w-full py-5 bg-white/5 text-slate-500 font-bold rounded-2xl flex items-center justify-center gap-2 cursor-not-allowed border border-white/5 uppercase text-xs tracking-tighter">
                    <Clock className="w-5 h-5" /> Премьера скоро
                  </button>
              )}
              
              <div className="flex gap-3">
                <button 
                  onClick={handleFavorite} 
                  disabled={isActionLoading}
                  className={`flex-1 py-4 glass font-black text-xs tracking-wider rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-95 ${isFavorite ? 'text-pink-500 bg-pink-500/10 border-pink-500/40' : 'text-white hover:bg-white/10'}`}
                >
                  {isActionLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                    <>
                      <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} /> 
                      {isFavorite ? 'В ИЗБРАННОМ' : 'ИЗБРАННОЕ'}
                    </>
                  )}
                </button>
                 <button onClick={handleShare} className="py-4 px-5 glass hover:bg-white/10 text-white font-bold rounded-2xl transition-all active:scale-95">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          <div className="flex-1 pt-16 lg:pt-48">
             <div className="mb-12">
               <h1 className="text-4xl md:text-7xl font-display font-black text-white mb-6 leading-tight drop-shadow-2xl">{anime.title}</h1>
               <div className="flex flex-wrap items-center gap-6 text-xs font-black text-slate-400">
                 <div className="flex items-center gap-2 bg-yellow-400/20 px-4 py-2 rounded-xl text-yellow-400 border border-yellow-400/20">
                    <Star className="w-4 h-4 fill-current" /> {anime.rating}
                 </div>
                 <span className="bg-white/5 px-4 py-2 rounded-xl border border-white/5 text-white">{anime.year}</span>
                 <span className="bg-white/5 px-4 py-2 rounded-xl border border-white/5 uppercase tracking-[0.2em]">{anime.type}</span>
                 <span className="text-primary font-black uppercase tracking-[0.3em] bg-primary/10 px-4 py-2 rounded-xl border border-primary/20">{anime.status}</span>
               </div>
             </div>

             <div className="glass p-10 rounded-[2.5rem] mb-12 border border-white/5 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[100px] -mr-32 -mt-32"></div>
               <h3 className="text-sm font-black text-slate-500 mb-6 uppercase tracking-[0.4em] flex items-center gap-3">
                 <div className="w-8 h-[2px] bg-primary"></div> Описание тайтла
               </h3>
               <p className="text-slate-300 leading-relaxed text-lg font-medium">{anime.description}</p>
               <div className="flex flex-wrap gap-3 mt-10">
                 {anime.genres.map(g => (
                   <span key={g} className="px-5 py-2.5 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black text-slate-400 hover:text-primary hover:border-primary/40 transition-all cursor-default uppercase tracking-widest">
                     {g}
                   </span>
                 ))}
               </div>
             </div>

             {hasContent && (
                 <div className="mb-12">
                   <div className="flex items-center justify-between mb-8">
                     <h3 className="text-2xl font-black text-white flex items-center gap-4 uppercase tracking-tighter">
                       Список серий
                       <span className="text-[10px] text-slate-600 bg-white/5 px-3 py-1 rounded-full border border-white/5 font-black">{episodes.length} EP</span>
                     </h3>
                   </div>
                   <div className="grid gap-4 max-h-[700px] overflow-y-auto custom-scrollbar pr-4">
                     {episodes.map((ep) => (
                       <Link key={ep.id} to={`/watch/${anime.id}?ep=${ep.number}`} className="flex gap-6 p-4 rounded-3xl glass hover:bg-white/10 border border-transparent hover:border-white/10 transition-all group items-center relative overflow-hidden">
                         <div className="relative w-52 aspect-video flex-shrink-0 rounded-2xl overflow-hidden shadow-2xl">
                           <img src={ep.thumbnail} alt={ep.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                           <div className="absolute inset-0 bg-primary/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-[2px]">
                             <PlayCircle className="w-12 h-12 text-white fill-current shadow-2xl" />
                           </div>
                         </div>
                         <div className="flex flex-col justify-center min-w-0 flex-1">
                           <h4 className="font-black text-white group-hover:text-primary transition-colors text-xl mb-2 truncate uppercase tracking-tight">{ep.title}</h4>
                           <div className="flex items-center gap-4">
                              <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Серия {ep.number}</span>
                              <div className="w-1 h-1 rounded-full bg-slate-700"></div>
                              <span className="text-[9px] font-black text-accent bg-accent/10 px-2 py-0.5 rounded border border-accent/20 uppercase">FHD 1080P</span>
                           </div>
                         </div>
                       </Link>
                     ))}
                   </div>
                 </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Details;
