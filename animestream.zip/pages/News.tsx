import React, { useEffect, useState } from 'react';
import { Calendar, ChevronRight, Megaphone, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { fetchNews } from '../services/shikimori';
import { NewsItem } from '../types';

const News: React.FC = () => {
  const [newsList, setNewsList] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadNews = async () => {
        setIsLoading(true);
        const data = await fetchNews();
        setNewsList(data);
        setIsLoading(false);
    }
    loadNews();
  }, []);

  if (isLoading) {
    return (
        <div className="min-h-screen flex items-center justify-center">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
        </div>
    );
  }

  if (newsList.length === 0) {
      return <div className="text-center py-20 text-white">Новости не найдены</div>
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      <div className="flex items-center gap-3 border-b border-white/5 pb-6">
        <Megaphone className="text-primary w-8 h-8" />
        <h1 className="font-display text-3xl font-black text-white">Все новости</h1>
      </div>

      <div className="grid gap-6">
         {newsList.map((item, idx) => (
            <Link 
              key={item.id + idx} 
              to={`/news/${item.id}`}
              className="group block p-6 glass rounded-2xl border border-white/5 hover:border-primary/30 transition-all hover:-translate-y-1 relative overflow-hidden"
            >
               <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-primary/5 to-transparent rounded-full blur-3xl -mr-20 -mt-20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
               
               <div className="relative z-10">
                   <div className="flex items-center gap-3 mb-3">
                       <span className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-[10px] font-bold text-primary uppercase">
                           {item.category}
                       </span>
                       <span className="text-[10px] text-slate-500 font-bold uppercase flex items-center gap-1">
                           <Calendar className="w-3 h-3" /> {item.date}
                       </span>
                   </div>

                   <h2 className="text-xl font-bold text-white mb-3 group-hover:text-primary transition-colors">
                       {item.title}
                   </h2>

                   <p className="text-slate-400 text-sm leading-relaxed mb-4 line-clamp-2">
                       {item.summary}
                   </p>

                   <div className="flex items-center gap-1 text-sm font-bold text-slate-300 group-hover:text-white mt-auto w-fit">
                      Читать полностью <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                   </div>
               </div>
            </Link>
         ))}
      </div>
    </div>
  );
};

export default News;