import React, { useRef, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, ChevronLeft, PlayCircle, Calendar, Clock, Star, Zap, Sparkles, Megaphone, ArrowRight, Loader2 } from 'lucide-react';
import AnimeCard from '../components/AnimeCard';
import { fetchAnimes, fetchCalendar, fetchNews, fetchAnimeDetails } from '../services/shikimori';
import { Anime, ScheduleItem, NewsItem } from '../types';

type HomeTab = 'trending' | 'new' | 'upcoming';

const Home: React.FC = () => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState<HomeTab>('trending');
  
  const [heroAnimes, setHeroAnimes] = useState<Anime[]>([]);
  const [trendingAnimes, setTrendingAnimes] = useState<Anime[]>([]);
  const [newAnimes, setNewAnimes] = useState<Anime[]>([]);
  const [upcomingAnimes, setUpcomingAnimes] = useState<Anime[]>([]);
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Hero Carousel Logic
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        // Parallel fetching
        const [trending, fresh, upcoming, calendarData, newsData] = await Promise.all([
          fetchAnimes({ order: 'popularity', limit: 10 }),
          fetchAnimes({ order: 'aired_on', status: 'ongoing', limit: 15 }),
          fetchAnimes({ order: 'popularity', status: 'anons', limit: 15 }),
          fetchCalendar(),
          fetchNews()
        ]);

        const heroIds = trending.slice(0, 5).map(a => a.id);
        const heroPromises = heroIds.map(id => fetchAnimeDetails(id));
        const heroItemsFull = await Promise.all(heroPromises);
        
        const validHeroItems = heroItemsFull.filter((item): item is Anime => item !== null);

        setHeroAnimes(validHeroItems);
        setTrendingAnimes(trending);
        setNewAnimes(fresh);
        setUpcomingAnimes(upcoming);
        setSchedule(calendarData);
        setNews(newsData);
      } catch (error) {
        console.error("Error loading home data", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);
  
  // Auto-slide effect
  useEffect(() => {
    if (heroAnimes.length === 0) return;
    const interval = setInterval(() => {
      setHeroIndex((prev) => (prev + 1) % heroAnimes.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [heroAnimes.length]);

  const currentHero = heroAnimes.length > 0 ? heroAnimes[heroIndex] : null;

  const currentList = activeTab === 'new' ? newAnimes : activeTab === 'upcoming' ? upcomingAnimes : trendingAnimes;

  const scrollSlider = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const scrollAmount = 600;
      sliderRef.current.scrollBy({
        left: direction === 'right' ? scrollAmount : -scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-20">
      {/* Hero Carousel Section */}
      {currentHero && (
        <section className="relative h-[65vh] w-full overflow-hidden group">
          {/* Background Images with Fade Transition */}
          {heroAnimes.map((anime, idx) => (
            <div 
              key={anime.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${idx === heroIndex ? 'opacity-100' : 'opacity-0 z-0'}`}
            >
              <img 
                src={anime.cover || anime.image} 
                alt={anime.title} 
                className="w-full h-full object-cover" 
              />
              {/* Gradients */}
              <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/40 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-dark via-dark/60 to-transparent" />
            </div>
          ))}
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-end pb-24 z-10">
            <div className="max-w-3xl space-y-6">
              {/* Key ensures animation triggers on index change */}
              <div key={currentHero.id} className="space-y-6 animate-in slide-in-from-bottom-5 fade-in duration-700">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 bg-primary text-white text-xs font-bold uppercase rounded-md shadow-lg shadow-primary/20">
                      #{heroIndex + 1} в Тренде
                    </span>
                    <span className="px-3 py-1 bg-white/10 text-slate-200 text-xs font-bold uppercase rounded-md backdrop-blur-md">
                      {currentHero.type}
                    </span>
                    <span className="flex items-center gap-1 text-yellow-400 text-xs font-bold">
                      <Star className="w-3 h-3 fill-current" /> {currentHero.rating}
                    </span>
                  </div>
                  
                  <h1 className="text-4xl md:text-6xl font-display font-black text-white leading-tight line-clamp-2 drop-shadow-lg">
                    {currentHero.title}
                  </h1>
                  
                  <p className="text-slate-200 text-lg line-clamp-3 leading-relaxed drop-shadow-md max-w-2xl">
                    {currentHero.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-4 pt-4">
                    <Link 
                      to={`/watch/${currentHero.id}`}
                      className="px-8 py-4 bg-primary hover:bg-violet-600 text-white font-bold rounded-xl flex items-center gap-2 transition-all shadow-lg shadow-primary/25 hover:shadow-primary/40 transform hover:-translate-y-1"
                    >
                      <PlayCircle className="w-5 h-5 fill-current" />
                      Смотреть
                    </Link>
                    <Link 
                      to={`/anime/${currentHero.id}`}
                      className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl flex items-center gap-2 transition-all backdrop-blur-md border border-white/10 hover:border-white/20"
                    >
                      Подробнее
                    </Link>
                  </div>
              </div>
            </div>
          </div>

          {/* Carousel Indicators */}
          <div className="absolute bottom-8 right-8 md:right-auto md:left-1/2 md:-translate-x-1/2 flex gap-3 z-20">
              {heroAnimes.map((_, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setHeroIndex(idx)}
                    className={`h-1.5 rounded-full transition-all duration-300 shadow-sm ${idx === heroIndex ? 'w-8 bg-primary' : 'w-2 bg-white/40 hover:bg-white'}`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
              ))}
          </div>
        </section>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
        
        {/* Tabbed Slider Section */}
        <section className="relative group/slider">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
            <div className="space-y-4">
              {/* Tabs */}
              <div className="flex items-center gap-1 p-1 bg-white/5 rounded-xl border border-white/5 w-fit">
                <button 
                  onClick={() => setActiveTab('trending')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'trending' ? 'bg-primary text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                  <Zap className="w-4 h-4" /> В тренде
                </button>
                <button 
                  onClick={() => setActiveTab('new')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'new' ? 'bg-primary text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                  <Sparkles className="w-4 h-4" /> Новинки
                </button>
                <button 
                  onClick={() => setActiveTab('upcoming')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'upcoming' ? 'bg-primary text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                  <Megaphone className="w-4 h-4" /> Анонсы
                </button>
              </div>
            </div>

            {/* Controls */}
            <div className="flex gap-2">
               <button 
                  onClick={() => scrollSlider('left')}
                  className="p-3 rounded-xl bg-surface border border-white/10 hover:bg-white/5 hover:text-white text-slate-400 transition-colors shadow-lg"
               >
                 <ChevronLeft className="w-5 h-5" />
               </button>
               <button 
                  onClick={() => scrollSlider('right')}
                  className="p-3 rounded-xl bg-surface border border-white/10 hover:bg-white/5 hover:text-white text-slate-400 transition-colors shadow-lg"
               >
                 <ChevronRight className="w-5 h-5" />
               </button>
            </div>
          </div>
          
          <div className="relative -mx-4 px-4 sm:px-0">
            <div 
              ref={sliderRef}
              className="flex gap-6 overflow-x-auto hide-scrollbar scroll-smooth pb-4 px-1 snap-x"
            >
              {currentList.map((anime, idx) => (
                <div key={`${anime.id}-${idx}-${activeTab}`} className="min-w-[160px] sm:min-w-[200px] md:min-w-[220px] snap-start animate-in fade-in zoom-in-95 duration-500">
                  <AnimeCard anime={anime} rank={activeTab === 'trending' ? idx + 1 : undefined} />
                </div>
              ))}
            </div>
             {/* Gradient fade on edges */}
            <div className="absolute top-0 bottom-0 left-0 w-16 bg-gradient-to-r from-dark to-transparent pointer-events-none md:hidden" />
            <div className="absolute top-0 bottom-0 right-0 w-16 bg-gradient-to-l from-dark to-transparent pointer-events-none md:hidden" />
          </div>
        </section>

        {/* Schedule Section */}
        <section>
          <div className="flex items-center gap-3 mb-8">
            <Calendar className="text-primary w-8 h-8" />
            <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-white">Расписание релизов</h2>
          </div>
          
          <div className="flex flex-col lg:flex-row gap-4 h-auto lg:h-[500px]">
            {schedule.map((item, idx) => {
              const currentDayIndex = new Date().getDay(); // 0-6 Sun-Sat
              const dayNames = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
              const isToday = item.day === dayNames[currentDayIndex];

              return (
                <div 
                  key={item.day} 
                  className={`
                    relative rounded-2xl p-4 border transition-all duration-500 ease-out overflow-hidden
                    flex flex-col
                    w-full lg:w-auto
                    lg:flex-1 lg:hover:flex-[3]
                    group
                    ${isToday ? 'border-primary/50 bg-primary/5' : 'glass border-white/5 hover:bg-surface'}
                  `}
                >
                  <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
                    <span className={`font-bold text-lg ${isToday ? 'text-primary' : 'text-slate-300 group-hover:text-white'}`}>{item.day}</span>
                    {isToday && <span className="text-[10px] bg-primary px-2 py-0.5 rounded-full text-white font-black">LIVE</span>}
                  </div>
                  
                  <div className="flex-1 mt-4 space-y-3 overflow-y-auto pr-2 custom-scrollbar">
                    {item.animes.length === 0 ? (
                      <div className="text-slate-600 text-xs italic">Нет эпизодов</div>
                    ) : (
                      item.animes.map((anime, aIdx) => (
                        <Link to={`/anime/${anime.id}`} key={aIdx} className="block group/anime p-2 rounded-lg hover:bg-white/5 transition-colors">
                          <div className="flex items-center gap-2 mb-1">
                             <Clock className="w-3 h-3 text-accent" />
                             <span className="text-[10px] font-bold text-accent">{anime.time}</span>
                          </div>
                          <span className="text-sm font-semibold text-slate-200 group-hover/anime:text-primary transition-colors line-clamp-1 group-hover:line-clamp-none">
                            {anime.title}
                          </span>
                        </Link>
                      ))
                    )}
                  </div>

                  <div className="absolute bottom-2 right-2 opacity-0 lg:group-hover:opacity-100 transition-opacity pointer-events-none">
                     <div className="p-1 bg-white/10 rounded-full">
                       <ChevronRight className="w-4 h-4 text-white" />
                     </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* News Section */}
        <section className="pb-10">
           <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
              <div className="flex items-center gap-3">
                 <Megaphone className="text-primary w-8 h-8" />
                 <h2 className="font-display text-2xl font-bold uppercase tracking-tight text-white">Новости мира аниме</h2>
              </div>
              <Link to="/news" className="flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-white transition-colors group">
                 Все новости <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {news.slice(0, 6).map((item) => (
                 <Link 
                   key={item.id} 
                   to={`/news/${item.id}`}
                   className="group flex flex-col p-6 glass rounded-2xl border border-white/5 hover:border-primary/30 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/5 relative overflow-hidden"
                 >
                    {/* Decorative Background Accent */}
                    <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-primary/10 transition-colors"></div>

                    <div className="flex items-center gap-3 mb-4">
                        <span className="px-2 py-1 bg-white/5 border border-white/10 rounded text-[10px] font-bold text-slate-300 uppercase">
                          {item.category}
                        </span>
                        <div className="flex items-center gap-1 text-[10px] text-slate-500 font-bold uppercase">
                          <Calendar className="w-3 h-3" /> {item.date}
                       </div>
                    </div>
                    
                    <h3 className="font-bold text-white text-lg leading-tight mb-3 group-hover:text-primary transition-colors line-clamp-2">
                       {item.title}
                    </h3>
                    
                    <div className="mt-auto pt-4 flex items-center gap-2 text-xs font-bold text-slate-400 group-hover:text-white transition-colors">
                       Читать далее <ChevronRight className="w-3 h-3 transition-transform group-hover:translate-x-1" />
                    </div>
                 </Link>
              ))}
           </div>
        </section>
      </div>
    </div>
  );
};

export default Home;