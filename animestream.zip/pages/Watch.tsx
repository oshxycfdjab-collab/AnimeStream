
import React, { useState, useEffect } from 'react';
import { useParams, Link, useSearchParams } from 'react-router-dom';
import { Download, Loader2, PlayCircle, Info, ChevronLeft, Tv, RefreshCw, Layers, ShieldAlert, Laptop, Zap, Globe } from 'lucide-react';
import { fetchAnimeDetails } from '../services/shikimori';
import { db } from '../services/db';
import { useAuth } from '../context/AuthContext';
import { Anime, Episode } from '../types';

interface PlayerSource {
  id: string;
  name: string;
  description: string;
  getUrl: (animeId: string, episode: number) => string;
}

const PLAYER_SOURCES: PlayerSource[] = [
  {
    id: 'shikivideo',
    name: 'ShikiVideo',
    description: 'Агрегатор (Libria, Band)',
    getUrl: (id, ep) => `https://shikivideo.ru/embed/${id}?episode=${ep}`
  },
  {
    id: 'alloha',
    name: 'Alloha',
    description: 'Честные 1080p (H.264)',
    getUrl: (id, ep) => `https://api.alloha.tv/?shikimori_id=${id}&episode=${ep}`
  },
  {
    id: 'videocdn',
    name: 'VideoCDN',
    description: 'VDS/Velour/Terra',
    getUrl: (id, ep) => `https://vdt28.videocdn.pw/shikimori/${id}?episode=${ep}`
  },
  {
    id: 'collaps',
    name: 'Collaps',
    description: 'Стабильный балансер',
    getUrl: (id, ep) => `https://api.strcollaps.com/embed/shikimori/${id}`
  },
  {
    id: 'anitype',
    name: 'AniType',
    description: 'Современный плеер',
    getUrl: (id, ep) => `https://anitype.site/embed/${id}`
  },
  {
    id: 'kodik',
    name: 'Kodik',
    description: 'Классика (нужен VPN)',
    getUrl: (id, ep) => `https://v1.kodik.info/find-player?shikimori_id=${id}&episode=${ep}`
  },
  {
    id: 'aniboom',
    name: 'AniBoom',
    description: 'Минимальный битрейт',
    getUrl: (id, ep) => `https://aniboom.one/embed/${id}`
  },
  {
    id: 'shikicinema',
    name: 'ShikiCinema',
    description: 'Зеркало агрегатора',
    getUrl: (id, ep) => `https://shikicinema.org/embed/${id}?episode=${ep}`
  }
];

const Watch: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  
  const [anime, setAnime] = useState<Anime | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [selectedEpisode, setSelectedEpisode] = useState(parseInt(searchParams.get('ep') || '1'));
  const [activeSource, setActiveSource] = useState<string>(() => localStorage.getItem('as_preferred_source') || PLAYER_SOURCES[0].id);
  const [isLoading, setIsLoading] = useState(true);
  const [playerKey, setPlayerKey] = useState(0);
  
  useEffect(() => {
    const loadData = async () => {
        if (!id) return;
        setIsLoading(true);
        try {
          const data = await fetchAnimeDetails(id);
          setAnime(data);
          
          if (data && data.episodesAired > 0) {
              const epList: Episode[] = Array.from({ length: data.episodesAired }, (_, i) => ({
                  id: `ep-${data.id}-${i + 1}`,
                  number: i + 1,
                  title: `Эпизод ${i + 1}`,
                  duration: "24:00",
                  thumbnail: data.image,
                  isFiller: false
              }));
              setEpisodes(epList);

              if (user?.email) {
                await db.addToHistory(user.email, data, selectedEpisode);
              }
          }
        } catch (err) {
          console.error("Watch Load Error", err);
        } finally {
          setIsLoading(false);
        }
    };
    loadData();
  }, [id, user, selectedEpisode]);

  const handleEpisodeChange = (num: number) => {
    setSelectedEpisode(num);
    setSearchParams({ ep: num.toString() });
  };

  const handleSourceChange = (sourceId: string) => {
    setActiveSource(sourceId);
    localStorage.setItem('as_preferred_source', sourceId);
    setPlayerKey(prev => prev + 1);
  };

  const reloadPlayer = () => setPlayerKey(prev => prev + 1);

  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-10 h-10 text-primary animate-spin" /></div>;

  if (!anime || anime.episodesAired === 0) {
    return (
        <div className="max-w-4xl mx-auto px-4 py-20 text-center">
            <Info className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Видео временно недоступно</h2>
            <p className="text-slate-400 mb-8">Возможно, серии еще не обработаны или плеер временно отключен.</p>
            <Link to={`/anime/${id}`} className="inline-flex items-center gap-2 text-primary font-bold transition-all hover:text-white">
                <ChevronLeft className="w-4 h-4" /> Вернуться назад
            </Link>
        </div>
    );
  }

  const currentSource = PLAYER_SOURCES.find(s => s.id === activeSource) || PLAYER_SOURCES[0];
  const playerUrl = currentSource.getUrl(id!, selectedEpisode);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      <div className="flex flex-col xl:flex-row gap-8">
        
        {/* Main Content: Player & Details */}
        <div className="flex-1 min-w-0">
          <div className="mb-6">
              <Link to={`/anime/${id}`} className="text-slate-500 hover:text-white transition-colors text-sm font-bold flex items-center gap-1 mb-2">
                 <ChevronLeft className="w-4 h-4" /> {anime.title}
              </Link>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <h1 className="text-2xl md:text-3xl font-black text-white">Серия {selectedEpisode}</h1>
                <div className="flex items-center gap-3">
                   <button onClick={reloadPlayer} className="p-2.5 bg-white/5 rounded-xl text-slate-400 hover:text-white transition-colors border border-white/5" title="Перезагрузить">
                      <RefreshCw className="w-4 h-4" />
                   </button>
                   <div className="px-4 py-2 bg-primary/10 border border-primary/20 rounded-xl flex items-center gap-2">
                      <Zap className="w-4 h-4 text-primary fill-current" />
                      <span className="text-[10px] font-black text-primary uppercase tracking-widest">{currentSource.name}</span>
                   </div>
                </div>
              </div>
          </div>

          <div className="relative aspect-video bg-black rounded-[2rem] overflow-hidden shadow-2xl border border-white/5 group ring-1 ring-white/10">
             <iframe 
                key={`${playerKey}-${activeSource}`}
                src={playerUrl}
                className="absolute inset-0 w-full h-full border-0"
                allow="autoplay; fullscreen"
                allowFullScreen
                title="Anime Player"
             />
             
             {/* Player Status Label */}
             <div className="absolute top-4 right-4 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="px-3 py-1 bg-black/80 backdrop-blur-md rounded-lg text-[10px] font-black text-white border border-white/10 uppercase tracking-tighter">
                  Streaming via {currentSource.id}
                </span>
             </div>
          </div>

          {/* New Multi-Source Grid */}
          <div className="mt-8">
             <div className="flex items-center gap-2 mb-4">
                <Layers className="w-4 h-4 text-slate-500" />
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest">Выберите сервер (балансер)</h3>
             </div>
             <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {PLAYER_SOURCES.map(source => (
                   <button
                      key={source.id}
                      onClick={() => handleSourceChange(source.id)}
                      className={`flex flex-col items-start p-3 rounded-2xl border transition-all ${activeSource === source.id ? 'bg-primary/20 border-primary shadow-lg shadow-primary/10' : 'bg-surface border-white/5 hover:border-white/20'}`}
                   >
                      <span className={`text-xs font-black uppercase mb-1 ${activeSource === source.id ? 'text-white' : 'text-slate-300'}`}>{source.name}</span>
                      <span className="text-[9px] text-slate-500 font-medium truncate w-full">{source.description}</span>
                   </button>
                ))}
             </div>
          </div>

          {/* Help Notice */}
          <div className="mt-8 flex items-start gap-4 p-5 rounded-3xl bg-amber-500/5 border border-amber-500/10">
             <ShieldAlert className="w-6 h-6 text-amber-500 shrink-0 mt-0.5" />
             <div className="text-xs text-slate-400 leading-relaxed">
                <p className="font-black text-amber-500 mb-1 uppercase tracking-tighter">Проблемы с воспроизведением?</p>
                Если "IP-адрес не найден", это означает, что ваш провайдер блокирует домен плеера. 
                1. Попробуйте другой <b>Сервер</b> из списка выше. 
                2. Используйте <b>VPN</b> или смените <b>DNS</b> в настройках Windows/Браузера на 8.8.8.8.
             </div>
          </div>

          <div className="mt-10 glass p-8 rounded-[2.5rem] border border-white/5 relative overflow-hidden">
             <div className="absolute top-0 left-0 w-2 h-full bg-primary/30"></div>
             <div className="relative z-10">
                <h2 className="text-xl font-black text-white mb-4 flex items-center gap-2 uppercase tracking-tighter">
                   <Info className="w-5 h-5 text-primary" /> Сюжет тайтла
                </h2>
                <p className="text-slate-400 leading-relaxed text-sm">{anime.description}</p>
             </div>
          </div>
        </div>

        {/* Sidebar: Episode List */}
        <div className="w-full xl:w-80 flex-shrink-0">
          <div className="glass rounded-[2.5rem] overflow-hidden flex flex-col h-[calc(100vh-160px)] sticky top-24 border border-white/10 shadow-2xl">
             <div className="p-6 border-b border-white/10 bg-white/[0.02] flex items-center justify-between">
                <h3 className="font-black text-white text-[10px] uppercase tracking-[0.2em]">Выбор эпизода</h3>
                <div className="flex items-center gap-1.5 px-2 py-1 bg-white/5 rounded-lg border border-white/10">
                   <Globe className="w-3 h-3 text-slate-500" />
                   <span className="text-[10px] font-black text-slate-500 uppercase">{episodes.length}</span>
                </div>
             </div>
             <div className="flex-1 overflow-y-auto p-4 space-y-2.5 custom-scrollbar">
                {episodes.map((ep) => (
                  <button 
                    key={ep.id} 
                    onClick={() => handleEpisodeChange(ep.number)}
                    className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all text-left group ${selectedEpisode === ep.number ? 'bg-primary/20 border border-primary/40 shadow-xl shadow-primary/5' : 'hover:bg-white/5 border border-transparent'}`}
                  >
                     <div className={`w-10 h-10 flex-shrink-0 rounded-xl flex items-center justify-center font-black text-sm transition-all ${selectedEpisode === ep.number ? 'bg-primary text-white scale-110' : 'bg-surface text-slate-500 group-hover:text-slate-300'}`}>
                        {ep.number}
                     </div>
                     <div className="min-w-0 flex-1">
                        <h4 className={`text-sm font-bold truncate ${selectedEpisode === ep.number ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`}>Серия {ep.number}</h4>
                        <div className="flex items-center gap-2 mt-0.5">
                           <span className="text-[9px] text-slate-600 uppercase font-black tracking-widest">FullHD 1080P</span>
                        </div>
                     </div>
                     {selectedEpisode === ep.number && <PlayCircle className="w-5 h-5 text-primary animate-pulse" />}
                  </button>
                ))}
             </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Watch;
