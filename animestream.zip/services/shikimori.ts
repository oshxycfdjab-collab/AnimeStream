import { Anime, ScheduleItem, NewsItem, Comment } from '../types';

const BASE_URL = 'https://shikimori.one/api';
const IMG_BASE_URL = 'https://shikimori.one';

export const GENRE_MAP: Record<string, number> = {
  'Экшен': 1,
  'Приключения': 2,
  'Машины': 3,
  'Комедия': 4,
  'Безумие': 5,
  'Демоны': 6,
  'Мистика': 7,
  'Драма': 8,
  'Этти': 9,
  'Фэнтези': 10,
  'Игры': 11,
  'Романтика': 12,
  'Исторический': 13,
  'Ужасы': 14,
  'Детское': 15,
  'Магия': 16,
  'Боевые искусства': 17,
  'Меха': 18,
  'Музыка': 19,
  'Пародия': 20,
  'Самураи': 21,
  'Шоджо': 25,
  'Шоунен': 27,
  'Школа': 23,
  'Фантастика': 24,
  'Космос': 29,
  'Спорт': 30,
  'Супер сила': 31,
  'Вампиры': 32,
  'Гарем': 35,
  'Повседневность': 36,
  'Сверхъестественное': 37,
  'Военное': 38,
  'Полиция': 39,
  'Психологическое': 40,
  'Триллер': 41,
  'Сейнен': 42,
  'Джосей': 43
};

interface ShikimoriAnime {
  id: number;
  name: string;
  russian: string;
  image?: {
    original?: string;
    preview?: string;
  };
  kind: string;
  score: string;
  status: string;
  episodes: number;
  episodes_aired: number;
  aired_on: string;
  released_on: string;
  description?: string;
  studios?: { name: string }[];
  genres?: { name: string; russian: string }[];
}

export const mapAnime = (data: ShikimoriAnime): Anime => {
  let description = 'Описание отсутствует.';
  if (data.description) {
    description = data.description.replace(/\[.*?\]/g, '').replace(/<\/?[^>]+(>|$)/g, "").trim();
  }

  let imageUrl = 'https://via.placeholder.com/300x450?text=No+Image';
  if (data.image) {
    const src = data.image.original || data.image.preview;
    if (src) imageUrl = src.startsWith('http') ? src : `${IMG_BASE_URL}${src}`;
  }

  return {
    id: data.id.toString(),
    title: data.russian || data.name,
    image: imageUrl,
    cover: imageUrl,
    rating: parseFloat(data.score) || 0,
    year: data.aired_on ? new Date(data.aired_on).getFullYear() : (data.released_on ? new Date(data.released_on).getFullYear() : 0),
    type: mapKind(data.kind),
    genres: data.genres ? data.genres.map(g => g.russian) : [],
    episodes: data.episodes || 0,
    episodesAired: data.episodes_aired || 0,
    status: mapStatus(data.status),
    description,
    studio: data.studios?.[0]?.name || 'Unknown'
  };
};

const mapKind = (kind: string): Anime['type'] => {
  if (['movie'].includes(kind)) return 'Movie';
  if (['ova', 'special'].includes(kind)) return 'OVA';
  if (['ona', 'music'].includes(kind)) return 'ONA';
  return 'TV Series';
};

const mapStatus = (status: string): Anime['status'] => {
  if (status === 'anons') return 'Upcoming';
  if (status === 'ongoing') return 'Ongoing';
  return 'Completed';
};

export const fetchAnimes = async (params: Record<string, any> = {}): Promise<Anime[]> => {
  const query = new URLSearchParams({
    limit: '20',
    page: '1',
    ...params
  }).toString();
  try {
    const response = await fetch(`${BASE_URL}/animes?${query}`, { headers: { 'User-Agent': 'AnimeStream' } });
    const data = await response.json();
    return data.map(mapAnime);
  } catch (error) {
    return [];
  }
};

export const fetchAnimeDetails = async (id: string): Promise<Anime | null> => {
  try {
    const response = await fetch(`${BASE_URL}/animes/${id}`);
    const data = await response.json();
    const anime = mapAnime(data);
    const screensRes = await fetch(`${BASE_URL}/animes/${id}/screenshots`);
    const screens = await screensRes.json();
    if (screens?.length) {
      const src = screens[0].original;
      anime.cover = src.startsWith('http') ? src : `${IMG_BASE_URL}${src}`;
    }
    return anime;
  } catch (error) {
    return null;
  }
};

export const fetchCalendar = async (): Promise<ScheduleItem[]> => {
  try {
    const response = await fetch(`${BASE_URL}/calendar`);
    const data = await response.json();
    const daysMap: Record<string, any[]> = { 'Пн': [], 'Вт': [], 'Ср': [], 'Чт': [], 'Пт': [], 'Сб': [], 'Вс': [] };
    const dayNames = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
    data.forEach((item: any) => {
      const date = new Date(item.next_episode_at);
      const dayName = dayNames[date.getDay()];
      if (daysMap[dayName]) {
        daysMap[dayName].push({
          id: item.anime.id.toString(),
          time: date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
          title: item.anime.russian || item.anime.name
        });
      }
    });
    return Object.entries(daysMap).map(([day, animes]) => ({ day, animes }));
  } catch (error) {
    return [];
  }
};

export const fetchNews = async (): Promise<NewsItem[]> => {
  try {
    const response = await fetch(`${BASE_URL}/topics?forum=news&limit=12&linked_type=Anime`);
    const data = await response.json();
    return data.map((topic: any) => ({
      id: topic.id.toString(),
      title: topic.topic_title,
      summary: topic.topic_title,
      date: new Date(topic.created_at).toLocaleDateString('ru-RU'),
      category: 'Новости',
      html_body: topic.html_body
    }));
  } catch (error) {
    return [];
  }
};

export const fetchNewsDetails = async (id: string): Promise<NewsItem | null> => {
  try {
    const response = await fetch(`${BASE_URL}/topics/${id}`);
    const topic = await response.json();
    return {
      id: topic.id.toString(),
      title: topic.topic_title,
      summary: topic.topic_title,
      date: new Date(topic.created_at).toLocaleDateString('ru-RU'),
      category: 'Новости',
      html_body: topic.html_body
    };
  } catch (error) {
    return null;
  }
};

export const fetchComments = async (topicId: string, isTopic = false): Promise<Comment[]> => {
  try {
    const type = isTopic ? 'Topic' : 'Anime';
    const response = await fetch(`${BASE_URL}/comments?commentable_id=${topicId}&commentable_type=${type}&limit=20`);
    const data = await response.json();
    return data.map((c: any) => ({
      id: c.id.toString(),
      text: c.body,
      date: new Date(c.created_at).toLocaleDateString('ru-RU'),
      user: { name: c.user.nickname, avatar: c.user.avatar }
    }));
  } catch (error) {
    return [];
  }
};