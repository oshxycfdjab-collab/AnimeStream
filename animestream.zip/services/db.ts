
import { Anime, User } from '../types';

// В реальном проекте здесь были бы вызовы к вашему API или Supabase SDK.
// Мы имитируем задержки сети и хранение на удаленном "сервере".
const API_DELAY = 500;

class RemoteDatabaseService {
  private async simulateNetwork() {
    return new Promise(resolve => setTimeout(resolve, API_DELAY));
  }

  // --- AUTH ---
  async register(userData: { name: string; email: string; password: string }): Promise<User | null> {
    await this.simulateNetwork();
    const users = JSON.parse(localStorage.getItem('cloud_users') || '[]');
    
    if (users.find((u: any) => u.email === userData.email)) {
      throw new Error('Пользователь с таким email уже существует');
    }

    const newUser: User = {
      name: userData.name,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userData.name}`,
      isPremium: false,
      watchedTime: "0ч 0м",
      episodesWatched: 0,
      email: userData.email // Adding email to type for cloud reference
    };

    const dbUser = { ...newUser, ...userData, id: Date.now().toString() };
    users.push(dbUser);
    localStorage.setItem('cloud_users', JSON.stringify(users));
    return newUser;
  }

  async login(credentials: { email: string; password: string }): Promise<User | null> {
    await this.simulateNetwork();
    const users = JSON.parse(localStorage.getItem('cloud_users') || '[]');
    const found = users.find((u: any) => u.email === credentials.email && u.password === credentials.password);
    
    if (!found) return null;
    const { password, ...sessionUser } = found;
    return sessionUser;
  }

  // --- FAVORITES (Server-side storage) ---
  async getFavorites(email: string): Promise<string[]> {
    await this.simulateNetwork();
    const allFavs = JSON.parse(localStorage.getItem('cloud_favorites') || '{}');
    return allFavs[email] || [];
  }

  async toggleFavorite(email: string, animeId: string): Promise<boolean> {
    await this.simulateNetwork();
    const allFavs = JSON.parse(localStorage.getItem('cloud_favorites') || '{}');
    if (!allFavs[email]) allFavs[email] = [];
    
    const index = allFavs[email].indexOf(animeId);
    let newState = false;
    if (index > -1) {
      allFavs[email].splice(index, 1);
      newState = false;
    } else {
      allFavs[email].push(animeId);
      newState = true;
    }
    localStorage.setItem('cloud_favorites', JSON.stringify(allFavs));
    return newState;
  }

  // --- HISTORY (Server-side storage) ---
  async getHistory(email: string): Promise<any[]> {
    await this.simulateNetwork();
    const allHistory = JSON.parse(localStorage.getItem('cloud_history') || '{}');
    return allHistory[email] || [];
  }

  async addToHistory(email: string, anime: Anime, episodeNum: number) {
    await this.simulateNetwork();
    const allHistory = JSON.parse(localStorage.getItem('cloud_history') || '{}');
    
    // Fix: Ensure the array exists before filtering
    if (!allHistory[email]) {
      allHistory[email] = [];
    }

    allHistory[email] = allHistory[email].filter((item: any) => item.animeId !== anime.id);
    allHistory[email].unshift({
      animeId: anime.id,
      title: anime.title,
      image: anime.image,
      episode: episodeNum,
      date: new Date().toISOString()
    });

    allHistory[email] = allHistory[email].slice(0, 30);
    localStorage.setItem('cloud_history', JSON.stringify(allHistory));
  }
}

export const db = new RemoteDatabaseService();
